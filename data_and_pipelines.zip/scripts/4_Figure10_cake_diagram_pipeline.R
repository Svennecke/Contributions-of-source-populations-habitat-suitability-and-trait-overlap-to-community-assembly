# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# ---- Analysis of the dispersal, environmental and biotic filter in presence/absence data ----
# 
# based on the Flow chart in Figure 2
#
# Authors: Nele Schuwirth and Svenja Gillmann
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

setwd() # set working directory to source file

dir.data      <- "../input/"
dir.output    <- "../output/"


# 1. input data matrix ####
# =-=-=-=-=-=-=-=-=-=-=-=-=

# load data

input.data <- read.table(paste0(dir.data,"master_table_cake_diagram.dat"),sep="\t",header=T,stringsAsFactors = F)

# set NAs in distance_source to 10 km
input.data$distance_source[is.na(input.data$distance_source)] <- 11000
site_types <- unique(input.data$site_type)

# 2. function to analyse the input data ####
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

analyse_filter <- function(input.data,
                           crit.dist=5000,    # distance from source in m above which dispersal filter applies
                           crit.habsuit=0.5,  # habitat suitability below which env filter applies
                           crit.traitol=0.5,  # trait overlap value above which competitive exclusion applies
                           site_types= c("nat","new","old")){ 
  
  res.df <- as.data.frame(matrix(0, nrow=3,ncol=14))
  colnames(res.df) <- c("site_type","npresent","nabsent","longcoltime",
                        "masseffect","allcondfav","highlycomp",
                        "dispersalfilter","envfilter","compexcl","unexplabs",
                        "na_distance_source","na_habitat_suitability","na_traitoverlap")
  res.df[,"site_type"] <- site_types
  
  for(i in 1:nrow(input.data)){
    
    rind <- grep(input.data[i,"site_type"],site_types)
    
    if(input.data[i,"presence"]==1){
      res.df[rind,"npresent"] <- res.df[rind,"npresent"]+1
      if(!is.na(input.data[i,"distance_source"])){
        if(input.data[i,"distance_source"] <= crit.dist ){
          if(!is.na(input.data[i,"habitat_suitability"])){
            if(input.data[i,"habitat_suitability"] >= crit.habsuit ){
              if(!is.na(input.data[i,"traitoverlap"])){
                if(input.data[i,"traitoverlap"] <= crit.traitol ){
                  res.df[rind,"allcondfav"] <- res.df[rind,"allcondfav"]+1
                } else {res.df[rind,"highlycomp"] <- res.df[rind,"highlycomp"]+1}
              } else {res.df[rind,"na_traitoverlap"] <- res.df[rind,"na_traitoverlap"]+1}
            } else {res.df[rind,"masseffect"] <- res.df[rind,"masseffect"]+1}
          } else {res.df[rind,"na_habitat_suitability"] <- res.df[rind,"na_habitat_suitability"]+1}
        } else {res.df[rind,"longcoltime"] <- res.df[rind,"longcoltime"]+1}
      } else {res.df[rind,"na_distance_source"] <- res.df[rind,"na_distance_source"]+1}
    } else {
      res.df[rind,"nabsent"] <- res.df[rind,"nabsent"]+1
      if(!is.na(input.data[i,"distance_source"])){
        if(input.data[i,"distance_source"] <= crit.dist ){
          if(!is.na(input.data[i,"habitat_suitability"])){
            if(input.data[i,"habitat_suitability"] >= crit.habsuit ){
              if(!is.na(input.data[i,"traitoverlap"])){
                if(input.data[i,"traitoverlap"] <= crit.traitol ){
                  res.df[rind,"unexplabs"] <- res.df[rind,"unexplabs"]+1
                } else {res.df[rind,"compexcl"] <- res.df[rind,"compexcl"]+1}
              } else {res.df[rind,"na_traitoverlap"] <- res.df[rind,"na_traitoverlap"]+1}
            } else { res.df[rind,"envfilter"] <- res.df[rind,"envfilter"]+1}
          } else {res.df[rind,"na_habitat_suitability"] <- res.df[rind,"na_habitat_suitability"]+1}
        } else { res.df[rind,"dispersalfilter"] <- res.df[rind,"dispersalfilter"]+1}
      } else {res.df[rind,"na_distance_source"] <- res.df[rind,"na_distance_source"]+1}
    }
  }
  
  res.df[4,] <- c("total",colSums(res.df[,2:14]))
  
  return(res.df)
}

# 3. apply the function to the test data ####
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

# check if default values of the function arguments are ok 
# (critical distances etc, otherwise specify them here or change defaults of the function)

res <- analyse_filter(input.data,crit.habsuit=0.5, crit.traitol = 0.8, crit.dist= 1500)
res_prop <- res %>% mutate(longcoltime_prop = as.numeric(longcoltime)/as.numeric(npresent), 
                           masseffect_prop = as.numeric(masseffect)/ as.numeric(npresent),
                           allcondfav_prop = as.numeric(allcondfav)/ as.numeric(npresent),
                           highlycomp_prop = as.numeric(highlycomp)/ as.numeric(npresent),
                           dispersalfilter_prop = as.numeric(dispersalfilter)/ as.numeric(nabsent),
                           envfilter_prop = as.numeric(envfilter)/ as.numeric(nabsent),
                           compexcl_prop = as.numeric(compexcl)/ as.numeric(nabsent),
                           unexplabs_prop = as.numeric(unexplabs)/ as.numeric(nabsent)) 

#Rename the site_type categories

res_prop$site_type <- recode(res_prop$site_type, 
                             "nat" = "Unimpacted", 
                             "new" = "Recently Restored", 
                             "old" = "Mature", 
                             "total" = "Total")


# determine proportions to plot cake diagram (Figure 10)

# Step 1: Calculate missing proportions for columns 15-18 (longcoltime to highlycomp)
res_prop$NA_prop1 <- 1 - rowSums(res_prop[, c("longcoltime_prop", "masseffect_prop", 
                                              "allcondfav_prop", "highlycomp_prop")])

# Step 2: Calculate missing proportions for columns 19-22 (dispersalfilter to unexplabs)
res_prop$NA_prop2 <- 1 - rowSums(res_prop[, c("dispersalfilter_prop", "envfilter_prop", 
                                              "compexcl_prop", "unexplabs_prop")])

# Step 3: Melt the data for the first pie chart (including the new "Other" category)
data_pie1 <- pivot_longer(res_prop[, c("site_type", "longcoltime_prop", "masseffect_prop", 
                                       "allcondfav_prop", "highlycomp_prop", "NA_prop1")], 
                          cols = -site_type, names_to = "Category", values_to = "Value")

# Step 4: Melt the data for the second pie chart (including the new "Other" category)
data_pie2 <- pivot_longer(res_prop[, c("site_type", "dispersalfilter_prop", "envfilter_prop", 
                                       "compexcl_prop", "unexplabs_prop", "NA_prop2")], 
                          cols = -site_type, names_to = "Category", values_to = "Value")

data_pie1 <- data_pie1 %>%
  group_by(site_type) %>%
  mutate(Percentage = Value * 100)

data_pie2 <- data_pie2 %>%
  group_by(site_type) %>%
  mutate(Percentage = Value * 100)

# Get the positions
data_pie2 <- data_pie2 %>% 
  mutate(csum = rev(cumsum(rev(Value))), 
         pos = Value/2 + lead(csum, 1),
         pos = if_else(is.na(pos), Value/2, pos))


data_pie1$Category <- factor(data_pie1$Category, levels = c("longcoltime_prop","masseffect_prop", "highlycomp_prop",
                                                            "allcondfav_prop","NA_prop1" ))

data_pie1$site_type <- factor(data_pie1$site_type, levels = c("Recently Restored","Mature", "Unimpacted",  "Total"))


# First Pie Chart
pie_chart_1 <- ggplot(data_pie1, aes(x = "", y = Value, fill = Category)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  facet_wrap(~site_type) +
  labs(title = "", fill = "Outcomes") +
  geom_label_repel(aes(label = paste0(round(Percentage, 1), "%")), 
                   position = position_stack(vjust = 0.5), size = 4, colour="white",
                   show.legend = FALSE, box.padding = 0) +
  scale_fill_manual(values = c("longcoltime_prop" = "#D16103", "masseffect_prop" = "#52854C", 
                               "allcondfav_prop" = "#C4961A",
                               "highlycomp_prop" = "#4E84C4", "NA_prop1" = "black"),
                    labels = c("long colonisation time",  "mass effect",
                               "highly competitive", "all conditions favourable",
                               "NA"),
                    guide = guide_legend(nrow = 2)) + 
  
  theme_void() +
  theme(legend.position = "bottom", legend.text= element_text(size= 12, family= "serif"))+
  theme(text = element_text(size = 14, family = "serif"),
        strip.text = element_text(size = 14, face = "bold"),  # Increases facet title size
        legend.position = "bottom", legend.title = NULL)

pie_chart_1



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Second Pie Chart -> absent taxa ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

data_pie2$Category <- factor(data_pie2$Category, levels = c("dispersalfilter_prop","envfilter_prop", "compexcl_prop",
                                                            "unexplabs_prop","NA_prop2" ))

data_pie2$site_type <- factor(data_pie2$site_type, levels = c(  "Recently Restored","Mature", "Unimpacted",  "Total"))

pie_chart_2 <- 
  ggplot(data_pie2, aes(x = "", y = Value, fill = Category)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  facet_wrap(vars(site_type), ncol=2, nrow=2) +
  labs(title = "", fill= "Outcomes") +
  geom_label_repel(aes(label = paste0(round(Percentage, 1), "%")), 
                   position = position_stack(vjust = 0.5), size = 4, colour="white", 
                   show.legend = FALSE, box.padding = 0)+
  scale_fill_manual(values = c("dispersalfilter_prop" = "#D16103", "envfilter_prop" = "#52854C", 
                               "compexcl_prop" = "#4E84C4",
                               "unexplabs_prop" = "#C4961A", "NA_prop2" = "black"),
                    labels = c("dispersal filter","environmental filter", 
                               "competitive exclusion",  "unexplained absences", "NA"),
                    guide = guide_legend(nrow = 2)) + 
  theme_void() +
  theme(legend.position = "bottom", legend.text= element_text(size= 12, family= "serif"))+
  theme(text = element_text(size = 14, family = "serif"),
        strip.text = element_text(size = 14, face = "bold"),  # Increases facet title size
        legend.position = "bottom", legend.title = NULL)

pie_chart_2


