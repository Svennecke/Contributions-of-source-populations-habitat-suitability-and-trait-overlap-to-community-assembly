# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# 
# --- Models for Organic matter ---
#
# Authors: Emma Chollet, Nele Schuwirth and Svenja Gillmann
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

getwd() # show working directory, ! set working directory to source file ('saproby_nutrients_model.r') location
rm(list=ls()) # free workspace
graphics.off() # clean graphics display

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Directory and file definitions: ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

dir.data                <- "../input/"
dir.output              <- "../output/"

file.chemisty.data      <- "Habitat_suitability/Saprobity_classification/boye_chemistry_alldata_2022.dat"

# ~~~~~~~~~~
# Read data: ####
# ~~~~~~~~~~
data.chemistry          <- read.table(paste0(dir.data,file.chemisty.data),header=TRUE,sep="\t", stringsAsFactors=FALSE) 

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Packages and functions
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if ( !require("dplyr") ) { install.packages("dplyr"); library("dplyr") }  
if ( !require("lubridate") ) { install.packages("lubridate"); library("lubridate") }


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Prepare chemistry data - change date into date format
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
data.chemistry$date2 <- as.Date(data.chemistry$date, "%d.%m.%Y")
data.chemistry <- data.chemistry %>%
  mutate(year = year(date2), 
         month = month(date2), 
         day = day(date2))



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Chemistry data across sampling times 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Dissolved O2 min ####
# ~~~~~~~~~~~~~~~~~~~~~~~~

# calculate O2 minimum
# min per year, then average over the years 
data.chemistry$O2_diss_mgperL <- as.numeric(data.chemistry$diss_oxygen_mgperl)
summary(data.chemistry$O2_diss_mgperL)
O2.min.year <- aggregate(data.chemistry$O2_diss_mgperL, 
                         by=list(StationNo=data.chemistry$site_name, 
                                 Year=data.chemistry$year), 
                         FUN = "min", na.rm=T)
unique(O2.min.year$Year)
# O2.min.year <- na.omit(O2.min.year)
length(unique(O2.min.year$StationNo))
# unique(O2.min.year$StationNo)
summary(O2.min.year$x)
O2.min <- aggregate(O2.min.year$x, 
                    by=list(StationNo=O2.min.year$StationNo), 
                    FUN = "mean", na.rm=T)
colnames(O2.min)[which(colnames(O2.min) == "x")] <- "O2_diss_min"
colnames(O2.min.year)[which(colnames(O2.min.year) == "x")] <- "O2_diss_min"
summary(O2.min$O2_diss_min)

# NH4 ammonium max ####
# ~~~~~~~~~~~~~~~~~~~~~~~~
# below detection limit -> substitute by 0  (highest value is <0.016)
summary(as.numeric(data.chemistry$ammonia_mg_l))   
for (i in 1:nrow(data.chemistry)){
  if (grepl("<", data.chemistry$ammonia_mg_l[i])) 
    data.chemistry$ammonia_mg_l[i] <- 0
}

data.chemistry$ammonia_mg_l <- as.numeric(data.chemistry$ammonia_mg_l)
summary(data.chemistry$ammonia_mg_l)
# calculate maximum ammonium
# max per year, then average over the years

NH4.max.year <- aggregate(data.chemistry$ammonia_mg_l, 
                          by=list(StationNo=data.chemistry$site_name,
                                  Year=data.chemistry$year), 
                          FUN = function(x) if(all(is.na(x))) NA else max(x, na.rm = TRUE))
NH4.max.year <- NH4.max.year[!is.infinite(NH4.max.year$x),]
length(unique(NH4.max.year$StationNo))
unique(NH4.max.year$Year)
summary(NH4.max.year$x)
NH4.max <- aggregate(NH4.max.year$x, 
                     by=list(StationNo=NH4.max.year$StationNo), 
                     FUN = "mean" )
colnames(NH4.max)[which(colnames(NH4.max) == "x")] <- "NH4_N_max"
colnames(NH4.max.year)[which(colnames(NH4.max.year) == "x")] <- "NH4_N_max"
# 8 NAs, length of the dataset should be the same as the number of StationNo
length(unique(NH4.max$StationNo))
summary(NH4.max$NH4_N_max)

# NO3 nitrate max ####
# ~~~~~~~~~~~~~~~~~~~~~~~~
# below detection limit -> substitute by 0  (highest value is <0.65)
summary(as.numeric(data.chemistry$nitrate_mg_l)) 
for (i in 1:nrow(data.chemistry)){
  if (grepl("<", data.chemistry$nitrate_mg_l[i])) 
    data.chemistry$nitrate_mg_l[i] <- 0
}
data.chemistry$nitrate_mg_l <- as.numeric(data.chemistry$nitrate_mg_l)
summary(data.chemistry$nitrate_mg_l)
# calculate maximum nitrate
# max per year, then average over the years 
NO3.max.year <- aggregate(data.chemistry$nitrate_mg_l, 
                          by=list(StationNo=data.chemistry$site_name,
                                  Year=data.chemistry$year), 
                          FUN = function(x) if(all(is.na(x))) NA else max(x, na.rm = TRUE))
NO3.max.year <- NO3.max.year[!is.infinite(NO3.max.year$x),]

length(unique(NO3.max.year$StationNo))
unique(NO3.max.year$Year)
summary(NO3.max.year$x)

NO3.max <- aggregate(NO3.max.year$x, 
                     by=list(StationNo=NO3.max.year$StationNo), 
                     FUN = "mean")
colnames(NO3.max)[which(colnames(NO3.max) == "x")] <- "NO3_N_max"
colnames(NO3.max.year)[which(colnames(NO3.max.year) == "x")] <- "NO3_N_max"
# 12 NAs, length of the dataset should be the same as the number of StationNo (345)
length(unique(NO3.max$StationNo))
summary(NO3.max$NO3_N_max)


# Total NH4 and NO3 median ####
# ~~~~~~~~~~~~~~~~~~~~~~~~
data.chemistry$NH4_NO3_tot_mgperL <- data.chemistry$ammonia_mg_l + 
  data.chemistry$nitrate_mg_l
summary(data.chemistry$NH4_NO3_tot_mgperL)
NH4.NO3.median.year <- aggregate(data.chemistry$NH4_NO3_tot_mgperL, 
                                 by=list(StationNo=data.chemistry$site_name,
                                         Year=data.chemistry$year), 
                                 FUN = "median",na.rm=T)
NH4.NO3.median <- aggregate(data.chemistry$NH4_NO3_tot_mgperL, 
                            by = list(StationNo=data.chemistry$site_name), 
                            FUN = "median", na.rm=T)
colnames(NH4.NO3.median)[which(colnames(NH4.NO3.median) == "x")] <- "NH4.NO3.median"
colnames(NH4.NO3.median.year)[which(colnames(NH4.NO3.median.year) == "x")] <- "NH4.NO3.median"

summary(NH4.NO3.median$NH4.NO3.median)


# DOC mean ####
# ~~~~~~~~~~~~~~~~~~~~~~~~
# below detection limit -> substitute by 0  (highest value is <0.016)
summary(as.numeric(data.chemistry$DOC_mg_l))   
for (i in 1:nrow(data.chemistry)){
  if (grepl("<", data.chemistry$DOC_mg_l[i])) data.chemistry$DOC_mg_l[i] <- 0
}
data.chemistry$DOC_mg_l <- as.numeric(data.chemistry$DOC_mg_l)
summary(data.chemistry$DOC_mg_l)

# calculate maximum ammonium
# mean per year, then average over the years 
DOC.mean.year <- aggregate(data.chemistry$DOC_mg_l, 
                           by=list(StationNo=data.chemistry$site_name,
                                   Year=data.chemistry$year), 
                           FUN = "mean", na.rm=T)
length(unique(DOC.mean.year$StationNo))
unique(DOC.mean.year$Year)
summary(DOC.mean.year$x)
DOC.mean <- aggregate(DOC.mean.year$x, 
                      by=list(StationNo=DOC.mean.year$StationNo), 
                      FUN = "mean", na.rm=T)
colnames(DOC.mean)[which(colnames(DOC.mean) == "x")] <- "DOC_mean"
colnames(DOC.mean.year)[which(colnames(DOC.mean.year) == "x")] <- "DOC_mean"
# 19 NAs, length of the dataset should be the same as the number of StationNo (345)
length(unique(DOC.mean$StationNo))
summary(DOC.mean$DOC_mean)


# PO4 max ####
# ~~~~~~~~~~~~~~~~~~~~~~~~
# note use PO4_P_mgperL, the alternative is:PO4_P_filt_mgperL but this is not often available
# below detection limit -> substitute by 0  (highest value is <0.016)
for (i in 1:nrow(data.chemistry)){
  if (grepl("<", data.chemistry$total_phosphate_mg_l[i])) 
    data.chemistry$total_phosphate_mg_l[i] <- 0
}
data.chemistry$ortho.phosphate_mg_l<- as.numeric(data.chemistry$ortho.phosphate_mg_l)
summary(data.chemistry$ortho.phosphate_mg_l)
data.chemistry$total_phosphate_mg_l <- as.numeric(data.chemistry$total_phosphate_mg_l)
summary(data.chemistry$total_phosphate_mg_l)
# calculate maximum orthophospate
# max per year, then average over the years 
PO4.max.year <- aggregate(data.chemistry$ortho.phosphate_mg_l, 
                          by=list(StationNo=data.chemistry$site_name,
                                  Year=data.chemistry$year), 
                          FUN = function(x) if(all(is.na(x))) NA else max(x, na.rm = TRUE))
PO4.max.year <- PO4.max.year[!is.infinite(PO4.max.year$x),]
length(unique(PO4.max.year$StationNo))
unique(PO4.max.year$Year)
summary(PO4.max.year$x)
PO4.max <- aggregate(PO4.max.year$x, by=list(StationNo=PO4.max.year$StationNo), 
                     FUN = "mean", na.rm=T)
colnames(PO4.max)[which(colnames(PO4.max) == "x")] <- "PO4_max"
colnames(PO4.max.year)[which(colnames(PO4.max.year) == "x")] <- "PO4_max"
# 19 NAs, length of the dataset should be the same as the number of StationNo (345)
length(unique(PO4.max$StationNo))
summary(PO4.max$PO4_max)

# PO4 median ####
# ~~~~~~~~~~~~~~~~~~~~~~~~
PO4.median.year <- aggregate(data.chemistry$total_phosphate_mg_l, 
                             by=list(StationNo=data.chemistry$site_name,
                                     Year=data.chemistry$year),
                             FUN = "median", na.rm=T)
PO4.median.year <- PO4.median.year[!is.infinite(PO4.median.year$x),]
colnames(PO4.median.year)[which(colnames(PO4.median.year) == "x")] <- "PO4.median"

summary(PO4.median.year$PO4.median)


PO4.median <- aggregate(data.chemistry$total_phosphate_mg_l, 
                        by=list(StationNo=data.chemistry$site_name), 
                        FUN = "median", na.rm=T)
colnames(PO4.median)[which(colnames(PO4.median) == "x")] <- "PO4.median"

summary(PO4.median$PO4.median)


# join the chemistry data of each year
# ~~~~~~~~~~~~~~~~~~~~~~~~
chem.data <- left_join(NH4.max.year, O2.min.year, by=c("StationNo", "Year"))
chem.data <- left_join(chem.data, NO3.max.year, by=c("StationNo", "Year"))
chem.data <- left_join(chem.data, NH4.NO3.median.year, by=c("StationNo" , "Year"))
chem.data <- left_join(chem.data, DOC.mean.year, by=c("StationNo", "Year"))
chem.data <- left_join(chem.data, PO4.max.year, by=c("StationNo", "Year"))
chem.data <- left_join(chem.data, PO4.median.year, by=c("StationNo", "Year"))

dim(chem.data)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# join all data (rename dataframe to data for following section)
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
data <- chem.data

# interpolations based on Bernatowicz et al. 2009

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# create a saproby axis by interpolating O2 and NH4
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

### interpolate the saproby axis
### ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# interpolation O2_diss for german saprobic index

interpol.points.O2.new <- c(8, 6, 5, 4, 2)
saproby.class.O2.new   <- c(1, 2, 2.5, 3, 4)

xout.O2 <- data$O2_diss_min

#O2.interpol.old <- approx(interpol.points.O2.old, saproby.class.O2.old, xout=xout.O2, method = "linear", rule = 2)
O2.interpol.new <- approx(interpol.points.O2.new, saproby.class.O2.new, xout=xout.O2, method = "linear", rule = 2)
plot(approx(interpol.points.O2.new,   saproby.class.O2.new),  col = "steelblue", pch = "*",
     xlab="O2-diss concentration", ylab="WQ_sapro_individual_O2-diss",
     xlim=c(0,max(xout.O2, na.rm=T)),
     ylim= c(1, 4.2))
# points(approx(interpol.points.O2.old,   saproby.class.O2.old),col=2, pch = "*")
points(O2.interpol.new$x, O2.interpol.new$y, pch=17)  

# data <- cbind(data, O2.interpol.old$y)  ##` old version
data <- cbind(data, O2.interpol.new$y)
# plot(O2.interpol.old$y,O2.interpol.new$y)
colnames(data)[which(colnames(data)=="O2.interpol.new$y")] <- "Saproby_O2_diss"


# interpolate NH4_N_mgperL

# interpolate NH4_N_mgperL german saprobic index
interpol.points.NH4.new     <- c(0.04, 0.3, 0.6, 1.2, 2.41)
saproby.class.NH4.new <- c(1, 2, 2.5, 3, 4)

xout.NH4 <- data$NH4_N_max

#NH4.interpol.old <- approx(interpol.points.NH4.old, saproby.class.NH4.old, xout=xout.NH4, method = "linear", rule = 2)
NH4.interpol.new <- approx(interpol.points.NH4.new, saproby.class.NH4.new, xout=xout.NH4, method = "linear", rule = 2)
plot(approx(interpol.points.NH4.new,   saproby.class.NH4.new), col = "steelblue", pch = "*",
     xlab="NH4 concentration", ylab="WQ_sapro_individual_NH4",
     xlim=c(0,max(xout.NH4, na.rm=T)), ylim=c(1,4.2) )
# points(approx(interpol.points.NH4.old,   saproby.class.NH4.old), col = 2, pch = "*")
points(NH4.interpol.new$x, NH4.interpol.new$y, pch=17)

# data <- cbind(data, NH4.interpol.old$y)  ##` old version
data <- cbind(data, NH4.interpol.new$y)
# plot(NH4.interpol.old$y,NH4.interpol.new$y)
colnames(data)[which(colnames(data)=="NH4.interpol.new$y")] <- "Saproby_NH4_N"


# interpolate DOC_mgperL   #### based on email from Nele and paper by Bernatowicz et al 2009

# interpolate DOC_mgperL for german saprobic index
interpol.points.DOC     <- c(1.6, 4, 8, 16, 32)
saproby.class.DOC <- c(1, 2, 2.5, 3, 4)


xout.DOC <- data$DOC_mean

DOC.interpol <- approx(interpol.points.DOC, saproby.class.DOC, 
                       xout=xout.DOC, method = "linear", rule = 2)
plot(approx(interpol.points.DOC,   saproby.class.DOC), col = "steelblue", pch = "*",
     xlab="DOC concentration", ylab="WQ_sapro_individual_DOC",
     xlim=c(0,max(c(max(xout.DOC, na.rm=T), max(interpol.points.DOC)))), 
     ylim=c(1,4.2) )
points(DOC.interpol$x, DOC.interpol$y, pch=17)  
data <- cbind(data, DOC.interpol$y)
colnames(data)[which(colnames(data)=="DOC.interpol$y")] <- "Saproby_DOC"


# interpolate NO3_N_mgperL  #### based on email from Nele and paper by Bernatowicz et al 2009

# interpolate NO3_N_mgperL for german saprobic index
interpol.points.NO3     <- c(1, 2.5, 5, 10, 20)
saproby.class.NO3 <- c(1, 2, 2.5, 3, 4)

xout.NO3 <- data$NO3_N_max

NO3.interpol <- approx(interpol.points.NO3, saproby.class.NO3, xout=xout.NO3, method = "linear", rule = 2)
plot(approx(interpol.points.NO3,   saproby.class.NO3),col = "steelblue", pch = "*",
     xlab="NO3 concentration", ylab="WQ_sapro_individual_NO3",
     xlim=c(0,max(c(max(xout.NO3, na.rm=T), max(interpol.points.NO3)))), ylim=c(1,4.2) )
points(NO3.interpol$x, NO3.interpol$y, pch=17)  
data <- cbind(data, NO3.interpol$y)
colnames(data)[which(colnames(data)=="NO3.interpol$y")] <- "Saproby_NO3"


# interpolate PO4_P_mgperL   #### based on email from Nele and paper by Bernatowicz et al 2009

# interpolate PO4_P_mgperL for german saprobic index
interpol.points.PO4     <- c(0.02, 0.1, 0.2, 0.4,0.8)
saproby.class.PO4 <- c(1, 2, 2.5, 3, 4)

xout.PO4 <- data$PO4_max

PO4.interpol <- approx(interpol.points.PO4, saproby.class.PO4, xout=xout.PO4, method = "linear", rule = 2)
plot(approx(interpol.points.PO4,   saproby.class.PO4), col = "steelblue", pch = "*",
     xlab="PO4 concentration", ylab="WQ_sapro_individual_P04",
     xlim=c(0,max(c(max(xout.PO4, na.rm=T), max(interpol.points.PO4)))), ylim=c(1,4.2) )
points(PO4.interpol$x, PO4.interpol$y, pch=17)  
data <- cbind(data, PO4.interpol$y)
colnames(data)[which(colnames(data)=="PO4.interpol$y")] <- "Saproby_PO4"


## calculate maximum and mean saprobity classes (based on Bernatowicz et al 2009)
## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# 1) max of all chemical parameters
## use the loop, because some rows are all NA
data$saproby.max <- NA
for (i in 1:nrow(data)){ 
  if (!(all(is.na(data[i,c("Saproby_O2_diss", "Saproby_NH4_N",  "Saproby_DOC", "Saproby_NO3", "Saproby_PO4") ])))) {
    data[i,"saproby.max"] <- max(data[i,c("Saproby_O2_diss", "Saproby_NH4_N",  "Saproby_DOC", "Saproby_NO3", "Saproby_PO4") ], na.rm=T) 
  }     
}

# 2) mean of all chemical parameters
data$saproby.mean <- NA
for (i in 1:nrow(data)){ 
  if (!(all(is.na(data[i,c("Saproby_O2_diss", "Saproby_NH4_N",  "Saproby_DOC", "Saproby_NO3", "Saproby_PO4") ])))) {
    # data[i,"saproby.mean"] <- mean(data[i,c("Saproby_O2_diss", "Saproby_NH4_N",  "Saproby_DOC", "Saproby_NO3", "Saproby_PO4") ], na.rm=T) 
    data[i,"saproby.mean"] <- mean(unlist(c(data[i,c("Saproby_O2_diss", "Saproby_NH4_N",  "Saproby_DOC", "Saproby_NO3", "Saproby_PO4") ])), na.rm=T)
  }     
}


# save as Boye_saprobic_classes_2022.dat into Environmental data folder as basis for habitat suitability calcualtions


