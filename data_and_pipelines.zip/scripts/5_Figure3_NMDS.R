# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# ---- NMDS Analysis of site by species matrix Figure 3 ----
#
# Authors: Svenja Gillmann
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

setwd() # set working directory to source file

dir.data      <- "../input/NMDS/"

# load packages 

if ( !require("dplyr") ) { install.packages("dplyr"); library("dplyr") }
if ( !require("vegan") ) { install.packages("vegan"); library("vegan") } 
library(ggrepel)



# 1. input data matrix ####
# =-=-=-=-=-=-=-=-=-=-=-=-=

# load data

comm_data <- read.table(paste0(dir.data,"comm_data_t_mainsites.dat"),
                        sep="\t",header=T,stringsAsFactors = F)   # load site by taxa community data
colnames(comm_data) <- sub("^X", "", colnames(comm_data))
rownames(comm_data) <- comm_data[,1]


# Perform Non-metric Multidimensional Scaling (NMDS)
jacc_dist <- vegdist(comm_data[,-1], method = "jaccard")

set.seed(536)
nmds_results <- metaMDS(jacc_dist, k=3, maxit=999, trymax=500, wascores=T, scale=T)

stressplot(nmds_results)

# Extract stress value
stress_value <- nmds_results$stress
nmds_scores <- as.data.frame(scores(nmds_results))

group_rest <- as.data.frame(c("unimpacted", "recently restored", "mature", "recently restored",
                         "mature", "recently restored", "mature", rep("unimpacted", 2), 
                         rep("mature", 4), rep("recently restored", 2), rep("unimpacted", 2), 
                         rep("mature", 3)))
group_rest <- data.frame(group_rest = group_rest)
colnames(group_rest) <- "group_rest"

# add columns tp NMDS scores
nmds_scores$site  <- rownames(nmds_scores)
nmds_scores$group <- group_rest$group_rest
nmds_scores       <- nmds_scores %>%
                     separate(site, into = c("ID", "Year"), sep = "_")

# Environmental vectors

find_hull <- function(df) df[chull(df$NMDS1, df$NMDS2), ]
hulls <- nmds_scores %>% group_by(group) %>% do(find_hull(.))


# Plotting
colours <- c("darkseagreen", "coral2", "deepskyblue3")
colourblind <- c("unimpacted" = "#009E73",  # Green
                 "recently restored" = "#D55E00",  # Coral
                 "mature" = "#56B4E9")  # Blue

p <- ggplot(nmds_scores, aes(x = NMDS1, y = NMDS2, color =group)) +
  geom_point(size = 3) +
  geom_polygon(data = hulls, aes(x = NMDS1, y = NMDS2, fill = group, color = group), alpha = 0.3) +
  scale_fill_manual(labels = c("unimpacted", "recently restored", "mature"), 
                    values = colourblind, name= "site group") +
  scale_colour_manual(labels = c("unimpacted", "recently restored", "mature"), 
                      values = colourblind, name= "site group") +
  geom_text(aes(label = ID), vjust = 1.5, color = "black", family="serif") +
  annotate('text', y = 0.6, x= 0.4, family="serif", size=4,
           label=paste0('3D stress = ', round(stress_value, 2)))+
  theme_classic()

p_nmds <-  p+  theme(
  legend.position ="inside",
  legend.position.inside = c(0.1, 0.11),
  legend.background = element_rect(linetype = 1, size = 0.5, colour = 1)
)+
  theme(text = element_text(family= "serif", size=12),
        axis.text.x = element_text(size=12, "serif"),
        axis.text.y = element_text(size=12, "serif"))+
  theme(panel.border = element_rect(colour = "black", fill=NA),
  legend.background = element_rect(linetype = 2, size = 0.5, colour = 1))
p

tiff("nmds.tiff", units="cm", width=20, height=15, res=800)     
p_nmds
dev.off()