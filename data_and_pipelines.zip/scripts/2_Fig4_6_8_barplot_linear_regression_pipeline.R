# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#
# Barplots and linear regression analysis of distance to source, 
# habitat suitability and trait overlap
#
# Authors: Svenja Gillmann
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


setwd() # set working directory to the source file

# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Packages and functions ####
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=

if ( !require("dplyr") ) { install.packages("dplyr"); library("dplyr") }
if ( !require("tidyr") ) { install.packages("tidyr"); library("tidyr") }  
if ( !require("lubridate") ) { install.packages("lubridate"); library("lubridate") }
if ( !require("glmmTMB") ) { install.packages("glmmTMB"); library("glmmTMB") }


# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# global directory and file definitions: ####
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

dir.data      <- "../input/"

# from output folder

file.habsuit     <- "Barplots/habsuit_long_format.dat"  # tab separated txt file including the results 
                                                        # from the habitat suitability calculations
file.distance    <- "Barplots/source_pop_2022.dat"      # tab separated txt file including the results from
                                                        # "nearest_neighbour_pipeline"
file.competition <- "Barplots/gower_results_2022.dat"   # tab separated txt file including the results from
                                                        # "competition_pipeline.R"

# load files and create master table with all relevant data (from outputs)

habsuit_long           <-  read.table(paste0(dir.input,file.habsuit),header=TRUE,
                            sep="\t", stringsAsFactors=FALSE)
df_dist_to_source      <- read.table(paste0(dir.input,file.distance),header=TRUE,
                                sep="\t", stringsAsFactors=FALSE)
gower_pres_abs_compare <- read.table(paste0(dir.input,file.competition),header=TRUE,
                                     sep="\t", stringsAsFactors=FALSE)

# merge output from nearest neighbour analysis with habitat suitabilities

master_table_22 <- merge(habsuit_long, df_dist_to_source, 
                         by.x= c("ID", "species"),
                         by.y= c("site", "species"))

master_table_22 <- master_table_22 %>% separate(new_column, into = c("dist", "closest_site"), sep = "-")

# add restoration groups to the table 

master_table_22 <- master_table_22 %>%
  mutate(group_rest = case_when(
    site %in% c("BOYkl_22", "BRAohBo_22", "BRAob_22", "QUAohBo_22", "SCHohVo_22") ~ "nat",
    site %in% c("LIEohBo_22", "BOYuhHa_22", "NATohBo_22", "BOYohB224_22", "BOYohKi_22") ~ "new",
    site %in% c("BOYohSp_22", "BOYuhSp_22", "KIRun_22", "KIRob_22", "BOYohBr_22") ~ "old",
    site %in% c("HAAun_22", "HAAob_22", "WITob_22", "VORuhSc_22", "VORohBo_22") ~ "old",
    # Handle cases not covered by any condition
  ))

##### DISPERSAL BARRIER --> DISTANCE TO SOURCE POPULATIONS COMPARE PRESENT AND ABSENT TAXA #####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

master_table_22$dist <- as.numeric(master_table_22$dist)
max(na.omit(master_table_22$dist))

# Calculate the size of each group
group_size <- (10373.4) %/% 20

# Create groups based on the distance column
master_table_22$dist_group <- cut(master_table_22$dist, breaks = seq(0, 
                                                                     10373.4, 
                                                                     by = 500), labels = F)
master_table_22$dist_group <- replace(master_table_22$dist_group , is.na(master_table_22$dist_group ), 22)

# Calculate the ratio of present to absent taxa within each group

grouped_df_abs <- aggregate(occurrence ~ dist_group , data = master_table_22, 
                            function(x) sum(x == 0) / sum(x==0, x==1)*100)
grouped_df_pres <- aggregate(occurrence ~ dist_group, data = master_table_22, 
                             function(x) sum(x == 1) / sum(x==0, x==1)*100)
grouped_df_pres_n <- aggregate(occurrence ~ dist_group, data = master_table_22, 
                               function(x) sum(x == 1))
grouped_df_abs_n <- aggregate(occurrence ~ dist_group, data = master_table_22, 
                              function(x) sum(x == 0))

grouped_df_n_comb <- rbind(grouped_df_pres_n, grouped_df_abs_n)

# Create a new dataframe with the calculated ratios and group definitions
group_definition <- as.data.frame(paste0("> ",(0:(21-1)) * 500/1000, "-", (1:21) * 500/1000))
group_definition <- rbind(group_definition, c("No source"))
group_definition <- group_definition[-c(14,16, 19:21),]

ratio_pres <-  as.data.frame(grouped_df_pres)
ratio_abs <-  as.data.frame(grouped_df_abs)

dist_group_df1 <- data.frame(cbind( group_definition,ratio_pres)) #group_definition,
dist_group_df1$occ <- "present"

dist_group_df2 <- data.frame(cbind(group_definition,ratio_abs))
dist_group_df2$occ <- "absent"
dist_group_comb <- rbind(dist_group_df1, dist_group_df2)

colnames(grouped_df_n_comb) <- c("group", "count")
dist_group_comb <- cbind(dist_group_comb, grouped_df_n_comb)
dist_group_comb$dist_group <- as.factor(dist_group_comb$dist_group)

# ---------------------------------------------
# Barplot: Ratio per increasing distance group ####

plot_prop_disp <- 
  ggplot(dist_group_comb, aes(x = dist_group, y= occurrence, fill= occ, label = count)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(size = 3, position = position_stack(vjust = 0.5), family= "serif")+
  labs(x = "Distance group (km) ", y = "Proportion present/ absent taxa (%)", 
       fill="Occurrence")+
  scale_fill_manual(values= c( "#edae49", "#00AFBB"))+ 
  scale_x_discrete(labels=rbind(rep(group_definition))) +
  theme_classic()+
  theme(axis.text.x = element_text(size=11, family= "serif"),
        axis.text.y = element_text(size=11))+
  theme(text = element_text(family= "serif", size=12))+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


##### HABITAT/ TOLERANCE BARRIER --> HABITAT SUITABILITY PER FACTOR COMPARE PRESENT AND ABSENT TAXA #####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# > MEAN HABITAT SUITABILITY ####

# Create groups based on the distance column
master_table_22$mean_habsuit_group <- cut(as.numeric(master_table_22$mean_habsuit), breaks = seq(0.000, 
                                                                                                 1, 
                                                                                                 by = 0.1), labels = F)
master_table_22$mean_habsuit_group[is.na(master_table_22$mean_habsuit_group)] <- 1

# Calculate the ratio of present to absent taxa within each group
grouped_df_abs <- aggregate(occurrence ~ mean_habsuit_group, data = master_table_22, 
                            function(x) sum(x == 0) / sum(x==0, x==1)*100)
grouped_df_pres <- aggregate(occurrence ~ mean_habsuit_group, data = master_table_22, 
                             function(x) sum(x == 1) / sum(x==0, x==1)*100)

grouped_df_pres_n <- aggregate(occurrence ~ mean_habsuit_group, data = master_table_22, 
                               function(x) sum(x == 1))
grouped_df_abs_n <- aggregate(occurrence ~ mean_habsuit_group, data = master_table_22, 
                              function(x) sum(x == 0))

grouped_df_n_comb <- rbind(grouped_df_pres_n, grouped_df_abs_n)
# Create a new dataframe with the calculated ratios and group definitions
group_definition_habsuit <- as.data.frame(paste0("> ", (0:9) * 0.1, "-", (1:10) * 0.1))
colnames(group_definition_habsuit) <- "habitat suitability"

ratio_pres <-  as.data.frame(grouped_df_pres)
ratio_abs <-  as.data.frame(grouped_df_abs)

mean_habsuit_group_df1 <- data.frame(cbind(group_definition_habsuit, ratio_pres))
mean_habsuit_group_df1$occ <- "present"

mean_habsuit_group_df2 <- data.frame(cbind(group_definition_habsuit, ratio_abs))
mean_habsuit_group_df2$occ <- "absent"

mean_habsuit_group_comb <- rbind(mean_habsuit_group_df1, mean_habsuit_group_df2)

colnames(grouped_df_n_comb) <- c("group", "count")
mean_habsuit_group_comb <- cbind(mean_habsuit_group_comb, grouped_df_n_comb)


# Plot the ratio per habitat suitability group

plot_prop_habsuit <- 
  ggplot(mean_habsuit_group_comb, aes(x = mean_habsuit_group, y= occurrence, fill= occ, label = count)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(size = 3, position = position_stack(vjust = 0.5), family= "serif")+
  labs(x = "Habitat suitability group", y = "Proportion of present/absent taxa (%)", 
       title = "",
       fill="Occurrence")+
  scale_x_discrete(limits=mean_habsuit_group_comb$mean_habsuit_group,
                   labels=group_definition_habsuit$`habitat suitability`) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  scale_fill_manual(values= c( "#edae49", "#00AFBB"))+ 
  theme_classic()+
  theme(axis.text.x = element_text(size=11, family= "serif"),
        axis.text.y = element_text(size=11))+
  theme(text = element_text(family= "serif", size=12))+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))



##### COMPETITION BARRIER ####
# ~~~~~~~~~~~~~~~~~~~~~~~~

# Create groups based on the trait overlap values

gower_pres_abs_compare$gow_group <- cut(as.numeric(gower_pres_abs_compare$max_value), breaks = seq(0.000,1, 
                                                                                            by = 0.1), labels = F)
gower_pres_abs_compare$gow_group[is.na(gower_pres_abs_compare$gow_group)] <- 1

# Calculate the ratio of present to absent taxa within each group
grouped_df_abs <- aggregate(occurrence ~ gow_group  , data = gower_pres_abs_compare, 
                            function(x) sum(x == 0) / sum(x==0, x==1)*100)
grouped_df_pres <- aggregate(occurrence ~ gow_group , data = gower_pres_abs_compare, 
                             function(x) sum(x == 1) / sum(x==0, x==1)*100)

grouped_df_pres_n <- aggregate(occurrence ~ gow_group, data = gower_pres_abs_compare, 
                               function(x) sum(x == 1))
grouped_df_abs_n <- aggregate(occurrence ~ gow_group, data = gower_pres_abs_compare, 
                              function(x) sum(x == 0))

grouped_df_n_comb <- rbind(grouped_df_pres_n, grouped_df_abs_n)


# Create a new dataframe with the calculated ratios and group definitions
group_definition <- as.data.frame(paste0("> ",(0:9) * 0.1, "-", (1:10) * 0.1))
group_definition <- group_definition[-c(1:3),]
group_definition <- as.data.frame(group_definition)
colnames(group_definition) <- "max_gow"

ratio_pres <-  as.data.frame(grouped_df_pres)
ratio_abs <-  as.data.frame(grouped_df_abs)

gow_group_df1 <- data.frame(cbind(group_definition, ratio_pres))
gow_group_df1$occ <- "present"

gow_group_df2 <- data.frame(cbind(group_definition, ratio_abs))
gow_group_df2$occ <- "absent"

gow_group_comb <- rbind(gow_group_df1, gow_group_df2)


colnames(grouped_df_n_comb) <- c("group", "count")
gow_group_comb <- cbind(gow_group_comb, grouped_df_n_comb)

# Plot the ratio per trait overlap group

plot_prop_comp <- 
ggplot(gow_group_comb, aes(x = gow_group, y= occurrence, fill= as.factor(occ), label = count)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_text(size = 3, position = position_stack(vjust = 0.5), family= "serif")+
  labs(x = "Trait overlap group", 
       y = "Proportion of present/absent taxa (%)", 
       fill="Occurrence",
       title = "")+
  scale_x_discrete(limits=gow_group_comb$gow_group,
                   labels=group_definition$max_gow) +
  scale_fill_manual(values= c("#edae49", "#00AFBB"))+ 
  theme_classic()+
  theme(text = element_text(size=12, family= "serif"))+
  theme(axis.text.x = element_text(size=11, family= "serif"),
        axis.text.y = element_text(size=11, family= "serif"))+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1, family= "serif"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# logistic models using function glmmTMB ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Dispersal ####
# ~~~~~~~~~ 

dist_all <- master_table_22 %>% subset(dist != "NA")

dist_all$occurrence <- as.numeric(as.character(dist_all$occurrence))
dist_all$dist_to_source <- dist_all$dist/1000
model_disp_all <- glmmTMB::glmmTMB(occurrence ~ dist_to_source+
                                     (dist_to_source|species), family="binomial", data=dist_all)

x   <- seq(0, 9, .1)
eta_all <- glmmTMB::fixef(model_disp_all)$cond[1]+glmmTMB::fixef(model_disp_all)$cond[2]*x

### regression plots distance to source populations ####

coefficients_dall <- glmmTMB::fixef(model_disp_all)$cond
pred_data_dall <- data.frame(x=seq(0, 9, .1), y=plogis(eta_all))
rsqbeta_dall <- cor(predict(model_disp_all, type = 'response'), 
                    dist_all$dist_to_source)^2
labelplotm_dall <- paste0('R-squared = ',round(rsqbeta_dall,2),
                          '\ny = ', round(coefficients_dall[1],2), 
                          round(coefficients_dall[2],2), ' * x')

disp_plall <- ggplot(dist_all, aes(x=dist_to_source, y=occurrence)) +
  geom_point(shape =1, size= 3)+
  geom_line(data=pred_data_dall, aes(x, y), col='bisque4', lwd=1.5)+
  labs(x= "Distance to nearest source population (km)", y= "Probability of occurrence")+
  #annotate('text', x=6, y=0.5, label=labelplotm_dall, family = "serif", size = 4.5)+
  scale_x_continuous(breaks=seq(0, 10, 1))+
  theme_classic()+
  theme(text = element_text(family= "serif", size=12))
disp_plall

disp_mod_plot <- cowplot::plot_grid(plot_prop_disp,  disp_plall,
                           labels = c('A', 'B'), ncol=1, 
                           label_fontfamily= "serif",
                           rel_heights=2:1,
                           vjust= c(1.5, -0.5))#,
disp_mod_plot

# jpeg("disp_mod_plot.jpg", units="cm", width=18, height=16, res=800)
# disp_mod_plot  # Create the plot
# dev.off() 

# Habitat suitability ####
# ~~~~~~~~~~~~~~~~~~~~

# add gower to master_table_22 and select columns for models

master_table_22_gow <- master_table_22 %>% 
  left_join(gower_pres_abs_compare[,c(4,5,6)], by = c("species" = "taxon", "site" = "site"))

mod_data <- master_table_22_gow %>% select(species, site, occurrence, dist, 
                                           mean_habsuit, max_value, group_rest) %>% 
  rename("dist_to_source"= "dist")

max(mod_data$dist_to_source, na.rm=T)

mod_data <- mod_data %>% mutate(dist = dist_to_source/10373.39)

mod_data <- mod_data %>% rename( "trait_overlap"="max_value")

hab_all <- mod_data %>% subset(mean_habsuit != "NA") %>% subset(mean_habsuit != "NaN") 

hab_all$occurrence <- as.numeric(as.character(hab_all$occurrence))
model_all <- glmmTMB::glmmTMB(occurrence ~ mean_habsuit +(mean_habsuit|species), family=binomial(link="logit"), data=hab_all)
DHARMa::simulateResiduals(model_all, plot = T)
summary(model_all)

x   <- seq(0, 1, .01)
eta_all <- glmmTMB::fixef(model_all)$cond[1]+glmmTMB::fixef(model_all)$cond[2]*x


### regression plot habitat suitability ####

coefficients1 <- glmmTMB::fixef(model_all)$cond
pred_data1 <- data.frame(x=seq(0, 1, .01), y=plogis(eta_all))
rsqbeta1 <- cor(predict(model_all, type = 'response'), hab_all$mean_habsuit)^2
labelplotm1 <- paste0('R-squared = ',round(rsqbeta1,2),
                      '\ny = ', round(coefficients1[1],2),'+', round(coefficients1[2],2), ' * x')

hab_pall <- ggplot(hab_all, aes(x=mean_habsuit, y=occurrence)) +
  geom_point(shape =1, size= 3)+
  geom_line(data=pred_data1, aes(x, y), col='bisque4', lwd=1.5)+
  labs(x= "Mean habitat suitability", y= "Probability of occurrence")+
  #annotate('text', x=0.6, y=0.7, label=labelplotm1, family = "serif", size = 4.5)+
  theme_classic()+
  theme(text = element_text(family= "serif", size=12))
hab_pall

summary(model_all)

hab_mod_plot <- cowplot::plot_grid(plot_prop_habsuit,  hab_pall,
                          labels = c('A', 'B'), ncol=1, 
                          label_fontfamily= "serif",
                          rel_heights=2:1,
                          vjust= c(1.5, -0.5)) 


hab_mod_plot

# jpeg("hab_mod_plot_resubmission.jpg", units="cm", width=18, height=16, res=800)
# hab_mod_plot  # Create the plot
# dev.off() 

# Competition #### 
# ~~~~~~~~~~~~

comp_all <- mod_data %>% subset(trait_overlap  != "NA") %>% subset(trait_overlap  != "NaN") 

comp_all$occurrence <- as.numeric(as.character(comp_all$occurrence))
model_comp_all <- glmmTMB::glmmTMB(occurrence ~ trait_overlap  +(trait_overlap |species), family=binomial(link="logit"), data=comp_all)

### regression plot trait overlap ####
x   <- seq(0.3, 1, .01)
eta1 <- glmmTMB::fixef(model_comp_all)$cond[1]+glmmTMB::fixef(model_comp_all)$cond[2]*x

coefficients1 <- glmmTMB::fixef(model_comp_all)$cond
pred_data1 <- data.frame(x=seq(0.3, 1, .01), y=plogis(eta1))
rsqbeta1 <- cor(predict(model_comp_all, type = 'response'), 
                comp_all$trait_overlap)^2
labelplotm1 <- paste0('R-squared = ',round(rsqbeta1,2),
                      '\ny = ', round(coefficients1[1],2),'+', 
                      round(coefficients1[2],2), ' * x')

comp_pall <- ggplot(comp_all, aes(x=trait_overlap, y=occurrence)) +
  geom_point(shape=1, size=3)+
  geom_line(data=pred_data1, aes(x, y), col='bisque4', lwd=1.5)+
  labs(x= "Maximum trait overlap", y= "Probability of occurrence")+
  theme_classic()+
  theme(text = element_text(family= "serif", size=12))
comp_pall

comp_mod_plot <-   cowplot::plot_grid(cowplot::plot_grid(plot_prop_comp,  comp_pall,
                                                labels = c('A', 'B'), ncol=1, 
                                                label_fontfamily= "serif",
                                                rel_heights=2:1,
                                                vjust= c(1.5, -0.5)))
comp_mod_plot

# jpeg("comp_mod_plot_resubmission.jpg", units="cm", width=18, height=16, res=800)
# comp_mod_plot  # Create the plot
# dev.off() 


# Export mod_data for boxplot analysis

filename <- paste(dir.input,"Boxplots/boxplot_mod_data.dat", sep="")
write.table(mod_data,filename, sep="\t", row.names=T,col.names=NA)

