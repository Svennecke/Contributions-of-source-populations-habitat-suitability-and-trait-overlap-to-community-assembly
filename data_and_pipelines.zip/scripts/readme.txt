The scripts contain all codes that were used for the analysis of the manuscript "Contributions of source populations, habitat suitability and trait overlap to benthic invertebrate community assembly in restored urban streams".

R-scripts 1a to 1e were used to calculate the values needed for the statistical analyses. 

A) Habitat suitability, Source populations and trait overlap

"1a_Saprobic_classes_pipeline.R" contains code that used the environmental data recorded bi-weekly in the Boye to calculate the Saprobic classes for each of the main sites. 
The results were used in Script "1b_Traitscore_pipeline.R", which holds the code which was used to connect species traits with environmental data to calculate the habitat suitabilities per factor.
"1c_Habitat_suitability_pipeline.R" summarises all habitat suitabilities to the final mean habitat suitabilities per sampling site, used for the final results.
"1d_Source_population_pipeline.R" holds the code that was used to determine the nearest source population per taxon and site.
"1e_Competition_pipeline.R" contains the code that was used to determine the maximum trait overlap between co-occurring and non co-occurring taxa.

B) Statistical analyses and figures

"2_Fig4_6_8_barplot_linear_regression_pipeline.R" contains the code that was used to calculate the proportions of present and absent taxa per distance, habitat suitabilty and trait overlap group. 
These were used to create the final barplots in Figures 4a, 6a and 8a. It also contains the linear regression analysis for each factor and the creation of the b- parts of Figures 4, 6 and 8.

"3_Fig5_7_9_boxplot_pipeline.R" contains the code for the models used to determine the emmeans per restoration group and factor. These were combined with barplots to create Figures 5, 7 and 9.

"4_Figure10_cake_diagram_pipeline.R" contains the code that was used to analyse most likely causes for taxon absences and presences and the creation of Figure 10.

"5_Figure3_NMDS.R" contains the code for the NMDS in Figure 3.

All data is contained in the respective input files.