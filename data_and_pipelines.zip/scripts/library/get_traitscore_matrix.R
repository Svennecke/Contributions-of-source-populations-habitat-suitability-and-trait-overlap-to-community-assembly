# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Linear interpolation function  
# "get.traitscore.matrix"
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


# the function for continuous traits
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

get_traitscore_matrix <- function(trait, midpoint=NULL, edges=NULL, traitcat, 
                                  env.cond, taxa.names, traits.n) 
{
  # arguments:
  # trait: string with trait name, e.g. "temp"
  # midpoint: numeric vector with mid points of trait classes,
  #           for interpolation at midpoints of trait classes
  #           provide either midpoints or edges
  # edges: numeric vector with edges of classes for interpolation at edges   
  #        e.g. edges <- c(0,5, 7,9, 11,17, 19,30) 
  # traitcat: vector of strings with the rownames corresponding to the trait
  #           in the trait database, e.g.  traitcat <- c("temperaturepref_vco",...)  
  # env.cond: named numeric vector with environmental conditions corresponding 
  #           to the trait and names corresponding to sample IDs
  # taxa.names: character vector with taxa names
  # traits.n: dataframe with taxa.names as rownames, traitcat as colnames,
  #           and values between 0 and 1 or NA as entries
  # return:
  # traitscore.matrix: matrix with Samp.IDs as rownames, "trait.taxa.names" as 
  #                    colnames, and interpolated habitat suitabilities between 
  #                    0 and 1 or NA as entries
  
  # to keep track at the end, where the function is in a large dataset
  j <- 0                                                              
  
  # make empty traitscore matrix
  traitscore.matrix <- matrix(                                                                               
    NA,
    nrow = length(names(env.cond)),
    ncol = length(taxa.names)
  )
  rownames(traitscore.matrix) <- names(env.cond)
  colnames(traitscore.matrix) <- paste(trait,taxa.names, sep=".")
  
  
  # interpolation on midpoints
  # =-=-=-=-=-=-=-=-=-=-=-=-=-
  if(length(midpoint)>0){
    
    # make small interpolation matrix for each taxon and trait
    for (taxon in taxa.names)
    {
      j <- j+1
      interpol.matrix.taxon <- matrix(data=NA, nrow=length(midpoint), ncol=2)
      rownames(interpol.matrix.taxon) <- traitcat
      interpol.matrix.taxon[,1] <- midpoint
      interpol.matrix.taxon[,2] <- t(traits.n[sub("_", "", taxon),traitcat])   
      
      if(!any(is.na(interpol.matrix.taxon[,2]))) 
      {
        
        # evaluate the interpolation matrix for the environmental conditions at the sampling sites
        xout <- env.cond
        habitatsuitability <- approx(interpol.matrix.taxon[,1], interpol.matrix.taxon[,2], xout, method = "linear", rule = 2)
        
        # # plot, to visualise what is happening
        # plot(interpol.matrix.taxon[,1], interpol.matrix.taxon[,2])
        # points(approx(interpol.matrix.taxon[,1], interpol.matrix.taxon[,2]), col = 2, pch = "*")
        
        # add the habitat suitability score to the traitscore matrix 
        for (i in 1:length(habitatsuitability$x))
        {
          traitscore.matrix [names(habitatsuitability$x[i]), paste(trait,taxon, sep=".")] <- habitatsuitability$y[i] 
        }
        
      }
      cat("taxon", j,"of",length(taxa.names),"\n") 
      
    }
  }
  
  # interpolation on edges
  # =-=-=-=-=-=-=-=-=-=-=-
  
  if(length(edges)>0){
    
    traitcat <- rep(traitcat, each=2)
    
    # make small interpolation matrix for each taxon and trait
    for (taxon in taxa.names)
    {
      #taxon <- taxa.names[1]
      j <- j+1
      interpol.matrix.taxon <- matrix(data=NA, nrow=length(edges), ncol=2)
      rownames(interpol.matrix.taxon) <- traitcat
      interpol.matrix.taxon[,1] <- edges
      interpol.matrix.taxon[,2] <- t(traits.n[sub("_", "", taxon),traitcat])   
      
      if(!any(is.na(interpol.matrix.taxon[,2]))) 
      {
        
        # evaluate the interpolation matrix for the environmental conditions at the sampling sites
        xout <- env.cond
        habitatsuitability <- approx(interpol.matrix.taxon[,1], interpol.matrix.taxon[,2], xout, method = "linear", rule = 2)
        
        # # plot, to visualise what is happening
        # plot(interpol.matrix.taxon[,1], interpol.matrix.taxon[,2])
        # points(approx(interpol.matrix.taxon[,1], interpol.matrix.taxon[,2]), col = 2, pch = "*")
        
        # add the habitat suitability score to the traitscore matrix 
        for (i in 1:length(habitatsuitability$x))
        {
          traitscore.matrix [names(habitatsuitability$x[i]), paste(trait,taxon, sep=".")] <- habitatsuitability$y[i] 
        }
        
      }
      cat("taxon", j,"of",length(taxa.names),"\n") 
      
    }
  }
  
  return(traitscore.matrix)
}


get_habsuit_categories <- function(trait, traitcat, 
                                   env.cond, taxa.names, traits.n) 
{
  # arguments:
  # trait: string with trait name, e.g. "temp"
  # traitcat: vector of strings with the rownames corresponding to the trait
  #           in the trait database, e.g.  traitcat <- c("temperaturepref_vco",...)  
  # env.cond: matrix with environmental conditions corresponding 
  #           to the trait categories and rownames corresponding to sample IDs
  # taxa.names: character vector with taxa names
  # traits.n: dataframe with taxa.names as rownames, traitcat as colnames,
  #           and values between 0 and 1 or NA as entries
  # return:
  # traitscore.matrix: matrix with Samp.IDs as rownames, "trait.taxa.names" as 
  #                    colnames, and interpolated habitat suitabilities between 
  #                    0 and 1 or NA as entries
  
  # to keep track at the end, where the function is in a large dataset
  j <- 0                                                              
  
  # make empty traitscore matrix
  habsuit.matrix <- matrix(                                                                               
    NA,
    nrow = nrow(env.cond),
    ncol = length(taxa.names)
  )
  rownames(habsuit.matrix) <- rownames(env.cond)
  colnames(habsuit.matrix) <- paste(trait,taxa.names, sep=".") # allenfalls nur taxa names?
  
  colnames_env.cond <-  paste(trait, colnames(env.cond),sep="_")
  if (length(intersect(traitcat, colnames_env.cond)) != length(traitcat)){
    warning("not all traitcat in env.cond")}
  
  trait_df <- traits.n[,traitcat][,colnames_env.cond]
  #trait_df <- traits.n[as.character(taxon),traitcat][,colnames_env.cond]
  
  for(taxon in taxa.names)
  {
    #taxon <- taxa.names[1]  
    for(i in 1:nrow(env.cond))
    {
      #i=1
      habsuit.matrix[i,paste(trait,taxon, sep=".")] <- sum(traits.n[as.character(taxon),traitcat] * env.cond[i,])
    }
  }
  #cat("taxon", j,"of",length(taxa.names),"\n") 
return(habsuit.matrix)
}


get_traitscore_matrix_weighted_optimum <- function(x_weight, y_edges, trait, cname_opti, cname_specific, 
                                        env.cond, taxa.names, traits) 
{
  # arguments:
  # x_weight: a vector containing the weight values
  # y_edges: a vector containing the edges for the interpolation
  # trait: string with trait name in env.data, e.g. "temp"
  # env.cond: named numeric vector with environmental conditions corresponding 
  #           to the trait and names corresponding to sample IDs
  # taxa.names: character vector with taxa names
  # traits: dataframe with taxa.names as rownames, 2 columns with optivalue and specificity as colnames
  #           and numerical values as entries
  # cname_opti: string providing column name in traits corresponding to optimum value
  # cname_specific: string providing column name in traits corresponding to specificity
  # return:
  # traitscore.matrix: matrix with Samp.IDs as rownames, "taxa.names" as 
  #                    colnames, and interpolated habitat suitabilities between 
  #                    0 and 1 or NA as entries
  
  
  # to keep track at the end, where the function is in a large dataset
  j <- 0                                                              
  
  # make empty traitscore matrix
  traitscore.matrix <- matrix(                                                                               
    NA,
    nrow = nrow(env.cond),
    ncol = length(taxa.names)
  )
  rownames(traitscore.matrix) <- env.cond$ID_year
  colnames(traitscore.matrix) <- paste(trait,taxa.names, sep=".")
  
  # interpolation on midpoints
  # =-=-=-=-=-=-=-=-=-=-=-=-=-
  
  # make small interpolation matrix for each taxon and trait
  for (taxon in taxa.names)
  { 
    #taxon = taxa.names[80]
    j <- j+1
    
    if (!is.na(traits[as.character(taxon), cname_specific])){
    delta <-  approx(x_weight, y_edges, xout= traits[as.character(taxon), cname_specific], 
                     method="linear",rule = 2)$y
    opti <- traits[as.character(taxon), cname_opti]
    midpoints <- c(opti-delta, opti, opti+delta)
    
    y_habsuit <- c(0,1,0)
    traitscore.matrix[,paste(trait,taxon, sep=".")] <- 
      approx(x= midpoints, y=y_habsuit, xout= env.cond[,trait], rule=2)$y
    
    }
    
    cat("taxon", j,"of",length(taxa.names),"\n") 
  }
  
  
  return(traitscore.matrix)
}



