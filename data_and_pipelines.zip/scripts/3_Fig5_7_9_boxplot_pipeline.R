# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# ---- Create Boxplots with emmeans ----
#
# Authors: Svenja Gillmann, Willem Kaijser
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

getwd() # show working directory, ! set working directory to source file ('saproby_nutrients_model.r') location
rm(list=ls()) # free workspace
graphics.off() # clean graphics display

# install and load packages

if ( !require("dplyr") ) { install.packages("dplyr"); library("dplyr") }
if ( !require("tidyr") ) { install.packages("tidyr"); library("tidyr") }  
if ( !require("lubridate") ) { install.packages("lubridate"); library("lubridate") }
if ( !require("gamlss") ) { install.packages("gamlss"); library("gamlss") }
if ( !require("emmeans") ) { install.packages("emmeans"); library("emmeans") }  


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Directory and file definitions: ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

dir.input               <- "../input/"
dir.output              <- "../output/"

#load data for boxplot and emmeans analysis

boxplot_mod_data           <-  read.table(paste0(dir.input,"Boxplots/boxplot_mod_data.dat"),header=TRUE,
                                      sep="\t", stringsAsFactors=FALSE)

mod_data_habitat <- boxplot_mod_data %>% select(c("mean_habsuit", "occurrence", "group_rest", "species")) %>%  
  subset(mean_habsuit != "NA") %>% subset(mean_habsuit != "NaN")

# Create GAM

mod <- gamlss(mean_habsuit ~ occurrence*group_rest, 
              random=~1|species,
              data = mod_data_habitat, 
              family= BEINF)

# determine emmeans

mod_occ            <- emmeans(mod, ~ occurrence|group_rest, type = "response")
summary_mod_occ    <- summary(pairs(mod_occ, reverse=T))
mod_occ

pl2_data_habitat <- plot(mod_occ, comparisons = TRUE, plotit=F)

# plot emmeans

pl2_habsuit <- ggplot(pl2_data_habitat, aes(x = group_rest, y = the.emmean, fill =factor(occurrence), color=factor(occurrence))) +
  geom_boxplot(show.legend = F)+   
  geom_crossbar(aes(xmin = as.numeric(group_rest) - 0.2, xmax = as.numeric(group_rest) + 0.2, 
                    ymin =  the.emmean - SE, ymax = the.emmean + SE, 
                    fill = factor(occurrence)), width=0.4,
                color = "black", 
                alpha = 0.5, 
                linetype= "blank",
                position = position_dodge(width = 0.75),
                show.legend = F) +
  scale_fill_manual(values = c("0" = "grey", "1" = "grey"), guide = "none")+ 
  scale_x_discrete(labels = c("unimpacted", "recently restored", "mature"))+ 
  geom_point(aes(y = the.emmean), position = position_dodge(width = 0.75), size = 3, 
             show.legend = T)+
  geom_errorbar(aes (ymin = asymp.LCL, ymax = asymp.UCL), 
                position = position_dodge(width = 0.75), width = 0.2, 
                show.legend = T) +
  scale_colour_manual(values = c("0" = "deepskyblue", "1" = "orange"), name="Occurrence", labels= c("absent", "present"))+
  theme_classic() +
  annotate('text', y = 0.6, x=c(1,2,3), family="serif",
           label=paste('p =',ifelse(summary_mod_occ$p.value<.001, '<0.001', round(summary_mod_occ$p.value,3))))+
  labs(x = "", 
       y = "Estminated Marginal Means (habitat)")+
  theme(text = element_text(size=12, family="serif"))+
  theme(axis.text.x = element_text(size=12, colour= "black"),
        axis.text.y = element_text(size=12, colour= "black"), 
        legend.text = element_text(size=12, colour= "black"))

pl2_habsuit

#### Competition emmeans ####

mod_data_comp    <- boxplot_mod_data %>% select(c("trait_overlap", "occurrence", "group_rest", "species")) %>%
  subset(trait_overlap != "NA") %>%  subset(trait_overlap != "NaN")
mod <- gamlss(trait_overlap ~ occurrence*group_rest, 
              random=~1|species, 
              data = mod_data_comp, family=BEOI)
mod_occ <- emmeans(mod, ~ occurrence|group_rest, type = "response")
summary_comp    <- summary(pairs(mod_occ, reverse=T))
mod_occ

pl2_data_comp <- plot(mod_occ, comparisons = TRUE, plotit=F)

pl2_comp <- ggplot(pl2_data_comp, aes(x = group_rest, y = the.emmean, fill =factor(occurrence), color=factor(occurrence))) +
  geom_boxplot(show.legend = F)+   
  geom_crossbar(aes(xmin = as.numeric(group_rest) - 0.2, xmax = as.numeric(group_rest) + 0.2, 
                    ymin =  the.emmean - SE, ymax = the.emmean + SE, 
                    fill = factor(occurrence)), width=0.4,
                color = "black", 
                alpha = 0.5, 
                linetype= "blank",
                position = position_dodge(width = 0.75),
                show.legend = F) +
  scale_fill_manual(values = c("0" = "grey", "1" = "grey"), guide = "none")+ 
  scale_x_discrete(labels = c("unimpacted", "recently restored", "mature"))+ 
  geom_point(aes(y = the.emmean), position = position_dodge(width = 0.75), size = 3, 
             show.legend = T)+
  geom_errorbar(aes (ymin = asymp.LCL, ymax = asymp.UCL), 
                position = position_dodge(width = 0.75), width = 0.2, 
                show.legend = T) +
  scale_colour_manual(values = c("0" = "deepskyblue", "1" = "orange"), name="Occurrence", labels= c("absent", "present"))+
  theme_classic() +
  annotate('text', y = 0.85, x=c(1,2,3), family="serif",
           label=paste('p =',ifelse(summary_comp$p.value<.001, '<0.001', round(summary_comp$p.value,3))))+
  labs(x = "", 
       y = "Maximum trait overlap (EMM)")+
  theme(text = element_text(size=12, family="serif"))+
  theme(axis.text.x = element_text(size=12, colour= "black"),
        axis.text.y = element_text(size=12, colour= "black"), 
        legend.text = element_text(size=12, colour= "black"))

pl2_comp

##### Dispersal Emmeans #####

mod_dist <- glmmTMB::glmmTMB(dist_to_source ~ occurrence*group_rest+(1|species), 
                        data = boxplot_mod_data, family=Gamma(link="identity"))
mod_occ <- emmeans(mod_dist, ~ occurrence|group_rest)
summary_dist    <- summary(pairs(mod_occ))
mod_occ

pl2_data <- plot(mod_occ, comparisons = TRUE, plotit=F)

pl2_dist <- ggplot(pl2_data, aes(x = group_rest, y = the.emmean, fill =factor(occurrence), color=factor(occurrence))) +
  geom_boxplot(show.legend = F)+   
  geom_crossbar(aes(xmin = as.numeric(group_rest) - 0.2, xmax = as.numeric(group_rest) + 0.2, 
                    ymin =  asymp.LCL, ymax = asymp.UCL, 
                    fill = factor(occurrence)), width=0.4,
                color = "black", 
                alpha = 0.5, 
                linetype= "blank",
                position = position_dodge(width = 0.75),
                show.legend = F) +
  scale_fill_manual(values = c("0" = "grey", "1" = "grey"), guide = "none")+ 
  scale_y_continuous(breaks = seq(1000, 3000, by = 500), labels = seq(1,3, by= 0.5)) +
  scale_x_discrete(labels = c("unimpacted", "recently restored", "mature"))+ 
  geom_point(aes(y = the.emmean), position = position_dodge(width = 0.75), size = 3, 
             show.legend = T)+
  geom_errorbar(aes (ymin = the.emmean-SE, ymax = the.emmean+SE), 
                position = position_dodge(width = 0.75), width = 0.2, 
                show.legend = T) +
  scale_colour_manual(values = c("0" = "deepskyblue", "1" = "orange"), name="Occurrence", labels= c("absent", "present"))+
  theme_classic() +
  annotate('text', y = 3000, x=c(1,2,3), family="serif",
           label=paste('p =',ifelse(summary_dist$p.value<.001, '<0.001', round(summary_dist$p.value,3))))+
  labs(x = "", 
       y = "Distance to nearest source [km] (EMM)")+
  theme(text = element_text(size=12, family="serif"))+
  theme(axis.text.x = element_text(size=12, colour= "black"),
        axis.text.y = element_text(size=12, colour= "black"), 
        legend.text = element_text(size=12, colour= "black"))
pl2_dist

#### -----------------------------
#### Combine Emmeans with boxplots ####
#### -----------------------------

#### Boxplot distance to nearest source population ####

box_disp <- ggplot(master_table_22, aes(x = group_rest, y = dist , fill= as.factor(occurrence))) +
  geom_boxplot(aes(x = group_rest, y = dist , fill= as.factor(occurrence))) +
  labs(title = "",
       x = "",
       y = "Distance to nearest source population (km)",
       fill="Occurrence",
       colour = "") +
  scale_y_continuous(breaks = seq(0, 11000, by = 1000), labels = seq(0,11, by= 1))+
  scale_x_discrete(labels = c("unimpacted", "recently restored", "mature"))+ 
  scale_fill_manual(values= c("#edae49", "#00AFBB"), labels= c("absent", "present"))+ 
  theme_classic() + 
  theme(#legend.title=element_blank(),
    text = element_text(size=12, family="serif"),
    axis.text.x = element_text(size=12, colour= "black"),
    axis.text.y = element_text(size=12, colour= "black"))+
  geom_pointrange(
    data = pl2_data,
    aes(y = the.emmean,ymin = the.emmean-SE, ymax = the.emmean+SE, color= "EMM"),
    size = 0.5,
    shape= 15,
    position = position_dodge(width = 0.75), show.legend = T)+
  scale_color_manual(values= c("darkred"), labels= c("EMMs"))+ 
  annotate('text', y = 10000, x=c(1,2,3), family="serif",
           label=paste('p =',ifelse(summary_dist$p.value<.001, '<0.001', round(summary_dist$p.value,3))))+
  guides(
    fill = guide_legend(order = 1, title = "Occurrence",
                        override.aes = list( shape = NA)),
    color = guide_legend(order = 2, title = "Statistics")
  ) 

box_disp

#### Boxplot habitat suitability ####

box_hab <- ggplot(boxplot_mod_data, aes(x = group_rest, y = mean_habsuit , fill= as.factor(occurrence))) +
  geom_boxplot(aes(x = group_rest, y = mean_habsuit , fill= as.factor(occurrence))) +
  labs(title = "",
       x = "",
       y = "Mean Habitat Suitability",
       fill="Occurrence",
       colour = "") +
  scale_y_continuous(breaks = seq(0, 1, by = 0.1), labels = seq(0,1, by= 0.1))+
  scale_x_discrete(labels = c("unimpacted", "recently restored", "mature"))+ 
  scale_fill_manual(values= c("#edae49", "#00AFBB"), labels= c("absent", "present"))+ 
  theme_classic() + 
  theme(#legend.title=element_blank(),
    text = element_text(size=12, family="serif"),
    axis.text.x = element_text(size=12, colour= "black"),
    axis.text.y = element_text(size=12, colour= "black"))+
  geom_pointrange(
    data = pl2_data_habitat,
    aes(y = the.emmean,ymin = the.emmean-SE, ymax = the.emmean+SE, color= "EMM"),
    size = 0.5,
    shape= 15,
    position = position_dodge(width = 0.75), show.legend = T)+
  scale_color_manual(values= c("darkred"), labels= c("EMMs"))+ 
  annotate('text', y = 1.1, x=c(1,2,3), family="serif",
           label=paste('p =',ifelse(summary_mod_occ$p.value<.001, '<0.001', round(summary_mod_occ$p.value,3))))+
  guides(
    fill = guide_legend(order = 1, title = "Occurrence",
                        override.aes = list( shape = NA)),
    color = guide_legend(order = 2, title = "Statistics")
  ) 

box_hab

#### Boxplot trait overlap ####

box_comp <- ggplot(boxplot_mod_data, aes(x = group_rest, y = trait_overlap , fill= as.factor(occurrence))) +
  geom_boxplot(aes(x = group_rest, y = trait_overlap , fill= as.factor(occurrence))) +
  labs(title = "",
       x = "",
       y = "Maximum Trait Overlap",
       fill="Occurrence",
       colour = "") +
  scale_y_continuous(breaks = seq(0, 1, by = 0.1), labels = seq(0,1, by= 0.1))+
  scale_x_discrete(labels = c("unimpacted", "recently restored", "mature"))+ 
  scale_fill_manual(values= c("#edae49", "#00AFBB"), labels= c("absent", "present"))+ 
  theme_classic() + 
  theme(#legend.title=element_blank(),
    text = element_text(size=12, family="serif"),
    axis.text.x = element_text(size=12, colour= "black"),
    axis.text.y = element_text(size=12, colour= "black"))+
  geom_pointrange(
    data = pl2_data_comp,
    aes(y = the.emmean,ymin = the.emmean-SE, ymax = the.emmean+SE, color= "EMM"),
    size = 0.5,
    shape= 15,
    position = position_dodge(width = 0.75), show.legend = T)+
  scale_color_manual(values= c("darkred"), labels= c("EMMs"))+ 
  annotate('text', y = 1.1, x=c(1,2,3), family="serif",
           label=paste('p =',ifelse(summary_comp$p.value<.001, '<0.001', round(summary_comp$p.value,3))))+
  guides(
    fill = guide_legend(order = 1, title = "Occurrence",
                        override.aes = list( shape = NA)),
    color = guide_legend(order = 2, title = "Statistics")
  ) 

box_comp

