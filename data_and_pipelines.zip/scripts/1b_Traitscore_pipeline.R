
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#
# Construct traitscore matrices, calculate habitat suitabilities
#
# Authors: Peter Vermeiren, updated by Nele Schuwirth and Svenja Gillmann
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

setwd() # set working directory to source file

# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Packages and functions ####
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=

if ( !require("dplyr") ) { install.packages("dplyr"); library("dplyr") }
if ( !require("tidyr") ) { install.packages("tidyr"); library("tidyr") }  
if ( !require("lubridate") ) { install.packages("lubridate"); library("lubridate") }

source("library/get_traitscore_matrix.R")
source("library/scale_traits.r")

# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# global directory and file definitions: ####
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

dir.data      <- "../input/Habitat_suitability/Environmental_data/"
dir.traits    <- "../input/Habitat_suitability/Traits/"

# from input folder
file.traits.fwe   <- "Boye_FWE_pref_fanalysis.dat"                      # tab separated txt file including the 
                                                                        # exported data from freshwaterecology.info 
                                                                        # ("saved as" in excel and rename to .dat)
file.traits.stowa <- "Boye_STOWA_pref_fanalysis.dat"                    # tab separated txt file including exported 
                                                                        # data from the STOWA databse ("saved as" in excel and rename to .dat)
file.inv          <- "Boye_taxa_pres_abs_main_sites.dat"                # P/A table of all taxa present at the RESIST sites in the 

# environmental data

file.env          <- "Substrate_estimates_pref.dat"                     # substrate estimates adjusted to substrate preference categories
file.env.temp     <- "Boye_tempdata_21.dat"                             # mean summer temperatures Boye 2021 (effect year = 2022)
file.env.flow     <- "boye_flow_velocity_2022.dat"                      # mean flow velocity per site 2022
file.saproby      <- "Boye_saprobic_classes_22.dat"                     # saprobity from output of saprobity script


# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# read global files + preparation ####
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

# read trait table (imported from freshwaterecology.info database)
traits.fwe  <- read.table(paste0(dir.traits,file.traits.fwe),header=TRUE,
                          sep="\t", stringsAsFactors=FALSE)
cind.taxa.fwe <- which(colnames(traits.fwe)=="ID_Art") # use IDs instead of taxon names
colnames(traits.fwe)[cind.taxa.fwe] <- "Taxon"  
rownames(traits.fwe) <- traits.fwe$Taxon

taxa.names.fwe <- traits.fwe$Taxon

# read trait table (imported from STOWA databse)
traits.stowa  <- read.table(paste0(dir.traits,file.traits.stowa),header=TRUE,
                            sep="\t", stringsAsFactors=FALSE)
cind.taxa.stowa <- which(colnames(traits.stowa)=="ID_Art") # use IDs instead of taxon names
colnames(traits.stowa)[cind.taxa.stowa] <- "Taxon"
rownames(traits.stowa) <- traits.stowa$Taxon
taxa.names.stowa <- traits.stowa$Taxon

# combine traits from fwe with stowa

traits <- left_join(traits.fwe, traits.stowa[,c(3,5:ncol(traits.stowa))])
rownames(traits) <- traits$Taxon

# add taxon names
taxa.names <- as.character(traits$Taxon)

# read environmental data
data.env  <- read.table(paste0(dir.data,file.env),header=T,sep="\t",
                        stringsAsFactors=FALSE)
cind.SampId <- which(colnames(data.env)=="id") # identify column with sample Id's
colnames(data.env)[cind.SampId] <- "SampId"

## =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==
## construct traitscore matrices
##  # for temperature, saprobic_cond and velocity:
##    # normal distribution (suitabilities defined by mean and range)
##    # interpolated at midpoints (1 suitability per class)
##    # interpolated at edges (1 suitability per class)
## =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==

## > temp - temperature ####
## =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

# ## suitability based on interpolation at edges
## -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# KLIWA index from Freshwater ecology
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# definitions
cname_opti <- "KLIWA_foctemp"
cname_specific <- "KLIWA_spec"
# weight and edges derived from supplementary material of Sundermann et al. 2022
# DOI: https://doi.org/10.1016/j.limno.2022.125980
x_weight <- c(0,1,2,3,4,6,10)
y_edges <- c(100,11,9,7,5,3,1)

# traitname of data.env
env.trait <- "mean_sum_temp"
env.temp <- read.table(paste0(dir.data,file.env.temp),header=T,sep="\t",
                       stringsAsFactors=FALSE)
env.cond <- env.temp[,c("mean_sum_temp", "ID_year")] # to be adapted!
rownames(env.cond) <- env.temp[,"ID_year"]

habsuit_temp <- get_traitscore_matrix_weighted_optimum(x_weight = x_weight, y_edges = y_edges,trait = "mean_sum_temp", cname_opti = cname_opti, 
                                                   cname_specific= cname_specific, 
                                                   env.cond= env.cond, taxa.names= taxa.names, 
                                                   traits= traits) 


## > saproby - saprobic_cond ####
## =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

## suitability based on interpolation at edges
## -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#load saprobity file
#import saprobic classes per sampling site (determined in a different script)

data.saproby <- read.table(paste0(dir.data,file.saproby),header=TRUE,
                           sep="\t", stringsAsFactors=FALSE)

data.saproby$Year_short <- gsub("2022", "22", data.saproby$Year)

#combine year and site in a new ID 
data.saproby$ID_year <- paste0(data.saproby$StationNo,"_", data.saproby$Year_short)

# definitions
cname_opti <- "sap_si"
cname_specific <- "sap_g"
# weight and edges derived from German saprobic index
x_weight <- c(4,8,16)
y_edges <- c(4,3,1)

# traitname of data.env
env.trait <- "saproby.max"
env.cond <- data.saproby[,c("saproby.max", "ID_year")] # to be adapted!
# rownames(env.cond) <- data.saproby[,"ID_year"]

habsuit_saprobity <- get_traitscore_matrix_weighted_optimum(x_weight = x_weight, y_edges = y_edges,trait =env.trait, cname_opti = cname_opti, 
                                                   cname_specific= cname_specific, 
                                                   env.cond= env.cond, taxa.names= taxa.names, 
                                                   traits= traits) 


## > velocity  ####
## =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

## suitability based on interpolation at edges
## -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

# load and prepare velocity data (mean velocity per sampling site)
data.env.flow  <- read.table(paste0(dir.data,file.env.flow),header=T,sep="\t",
                             stringsAsFactors=FALSE)

data.env.flow <- na.omit(data.env.flow)
data.env.flow$date <- as.Date(data.env.flow$date, "%d.%m.%Y")
data.env.flow <- data.env.flow %>%
  mutate(year = year(date))
data.env.flow$Year_short <- gsub("20","",as.character(data.env.flow$year))
#combine effect year and site in a new ID 
data.env.flow$ID_year <- paste0(data.env.flow$site_name,"_", data.env.flow$Year_short)


# definitions
trait     <- "flow_velocity_mpers"
midpoint  <- NULL
edges <-  c(0,0.01,0.02,0.05,0.06, 0.09,0.1,0.15,0.16, 0.25) 
traitcat  <- c("flow_sti","flow_zls","flow_ls","flow_ms", "flow_ss")
traits.flow <- traits[,traitcat]
traits.flow$Taxon <- rownames(traits.flow)
traits.flow <- scale.traits(traits.flow)
env.cond  <- data.env.flow$flow_velocity_mpers
names(env.cond) <- data.env.flow[,"ID_year"]
habsuit_velocity <- get_traitscore_matrix (trait=trait, midpoint=midpoint, edges=edges, 
                                   traitcat=traitcat, 
                                   env.cond=env.cond, taxa.names=taxa.names, 
                                   traits.n=traits.flow)  



## > suitability based on substrate types ####
## -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

trait <- "sub"

traitcat <- colnames(traits)[grep("sub_",colnames(traits))] 
traits_sub <- traits[,traitcat]
traits_sub[,"Taxon"] <- as.character(rownames(traits_sub))
traits_sub.n <- scale.traits(db.traits= traits_sub)
traits_sub.n <- traits_sub.n %>% rename("taxon" = "Taxon")

colnames(data.env) <- sub("pel_psa","pelpsa",colnames(data.env))

env.cond <- data.env[,-c(1:4)]
env.cond <- env.cond/rowSums(env.cond)
row.names(env.cond) <- data.env[,"SampId"]

habsuit_sub <- get_habsuit_categories(trait=trait, traitcat=traitcat, 
                                      env.cond=env.cond, taxa.names=taxa.names, traits.n=traits_sub.n) 


# use results in next script "1c_Habitat_suitability_pipeline.R"
