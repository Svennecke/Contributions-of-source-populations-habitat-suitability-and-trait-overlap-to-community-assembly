## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##
## --- Source populations ---
##
## Authors: Svenja Gillmann
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Preliminaries ####
# ~~~~~~~~~~~~~~~~~~
getwd() # show working directory, ! set working directory to source file ('main.r') location
rm(list=ls()) # free workspace
graphics.off() # clean graphics display
cat("\14") # clean the console

# Load libraries and functions ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if ( !require("dplyr") ) { install.packages("dplyr"); library("dplyr") }               # to sort, join, merge data
if ( !require("tidyr") ) { install.packages("tidyr"); library("tidyr") }               # to sort, join, merge data
if ( !require("ggplot2") ) { install.packages("ggplot2"); library("ggplot2") }         # for nice plots

# Directory and file definitions ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

dir.inputs      <- "../input/Source_populations/"

file.occ             <- "taxa_22_sub.dat"            # community presence absence data
file.taxalist        <- "Taxonnames_Boye_2022.dat"   # file with taxon names to connect to the taxa code
file.distance        <- "dist_between_sites.dat"     # distance between all sampling sites


taxa            <- read.table(paste0(dir.inputs,file.occ),header=T,
                              sep="\t", stringsAsFactors=FALSE, check.names = F)
taxalist        <- read.table(paste0(dir.inputs,file.taxalist),header=TRUE,
                              sep="\t", stringsAsFactors=FALSE)
site.dist       <- read.table(paste0(dir.inputs,file.distance),header=TRUE,
                              sep="\t", stringsAsFactors=FALSE)

# Determine per species and site the distance to closest source population ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# replace site labels by correct labels to match those within distance table

taxa <- taxa[,-1]

unique(site.dist$Von)

site.dist.instream   <- site.dist %>% select(c(1,2,6,12)) %>% rename(c("from_site" ="Von", 
                                                                       "to_site"="Zu", 
                                                                       "distance" ="Total_Leng_dist_water"))

site.dist.air        <- site.dist %>% select(c(1,2,9,12)) %>% rename(c("from_site" ="Von", 
                                                                       "to_site"="Zu", 
                                                                       "distance" ="Shape_Leng_dist_air"))

# determine nearest source site for each main site

df1 <- taxa

# aerial distance

df2 <- site.dist.air %>% filter(distance != "0")

# Function to find the closest site where the species occurs
find_closest_site <- function(from_site, species, df1, df2) {
  # Get the sites where the species occurs
  sites_with_species <- df1$site[!is.na(df1[[species]]) & df1[[species]] == 1]
  # Filter df2 for only relevant rows
  relevant_rows <- df2[df2$from_site == from_site & df2$to_site %in% sites_with_species, ]
  if (nrow(relevant_rows) > 0) {
    # Find the closest site
    closest_site <- relevant_rows[which.min(relevant_rows$distance), "to_site"]
    closest_distance <- min(relevant_rows$distance)
    return(data.frame(site = from_site, species = species, closest_site = closest_site, distance = closest_distance))
  } else {
    return(data.frame(site = from_site, species = species, closest_site = NA, distance = NA))
  }
}

# Initialize an empty dataframe to store results
result_df <- data.frame(site = character(), species = character(), closest_site = character(), distance = numeric(), group= character())

# Loop through each site and species in df1 to find the closest site where the species occurs (add  "&& df1[i, species] == 0" to line 106 to only select absent species)
for (i in 1:nrow(df1)) {
  for (species in colnames(df1)[-1]) {
    if (!is.na(df1[i, species]) ) {
      closest_info <- find_closest_site(df1[i, "site"], species, df1, df2)
      if (!is.null(closest_info)) {
        result_df <- rbind(result_df, closest_info)
      }
    }
  }
}

# Print the resulting dataframe
print(result_df)


# taxalist to connect names with ID
taxalist_ID_connect <- taxalist %>% mutate(ID_Art = as.character(ID_Art))
taxalist_ID_connect <- taxalist_ID_connect[,c(1:4)]

# new list 17.05.2024
taxalist_ID_connect$holo_mero <- c(rep("holo", 2), rep("holo", 11),"mero", rep("holo", 4), rep("mero", 31), 
                                   rep("holo", 8), rep("holo", 1), rep("holo", 4), rep("mero", 8),
                                   rep("holo", 5), rep("mero", 31), rep("holo", 1))

result_df_w_names <- left_join(result_df, taxalist_ID_connect, by= c("species"= "ID_Art"))

# safe arial distance in a new dataframe
result_df_w_names_air <- result_df_w_names %>% rename("air_dist" = "distance")

# instream distance 

df2 <- site.dist.instream %>% filter(distance != "0") %>% filter(Group3 == "DS")

# Initialize an empty dataframe to store results
result_df <- data.frame(site = character(), species = character(), closest_site = character(), distance = numeric(), group= character())

# Loop through each site and species in df1 to find the closest site where the species occurs (add  "&& df1[i, species] == 0" to line 106 to only select absent species)
for (i in 1:nrow(df1)) {
  for (species in colnames(df1)[-1]) {
    if (!is.na(df1[i, species]) ) {
      closest_info <- find_closest_site(df1[i, "site"], species, df1, df2)
      if (!is.null(closest_info)) {
        result_df <- rbind(result_df, closest_info)
      }
    }
  }
}

# Print the resulting dataframe
print(result_df)

result_df_w_names <- left_join(result_df, taxalist_ID_connect, by= c("species"= "ID_Art"))
result_df_w_names_instream <- result_df_w_names %>% rename("str_dist" = "distance")

result_df_w_names_air_instream <- merge(result_df_w_names_instream, result_df_w_names_air[,c(1:4)],
                                        by.x=c("site", "species"), by.y= c("site", "species"))

# add new column with either distance based on group

df_dist_to_source <- result_df_w_names_air_instream %>%
  mutate(
    new_column = ifelse(holo_mero == "holo", paste(str_dist, closest_site.x, sep = "-"), 
                        ifelse(str_dist < air_dist, paste(str_dist, closest_site.x, sep = "-"), 
                               paste(air_dist, closest_site.y, sep = "-"))))

# Use df_dist_to_source in "2_Fig4_6_8_barplot_linear_regression_pipeline" for the regression analysis and barplots
