## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
##
## --- Trait overlap ---
##
## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# load packages

if ( !require("dplyr") ) { install.packages("dplyr"); library("dplyr") }      
if ( !require("tidyverse") ) { install.packages("tidyverse"); library("tidyverse") }  
if ( !require("gawdis") ) { install.packages("gawdis"); library("gawdis") }  


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Directory and file definitions: ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

dir.data                <- "../input/Competition/"

# from input folder

file.preferences     <- "Spec_pref.dat"
file.taxa            <- "taxa_pa.dat"
file.taxaID          <- "Taxonnames_Boye_2022.dat" 
file.habitat_dist    <- "Habsuit_dist.dat"

# load files

taxa_pa    <- read.table(paste0(dir.data,file.taxa),header=TRUE,
                          sep="\t", stringsAsFactors=FALSE)
colnames(taxa_pa)  <- gsub("^X", "", colnames(taxa_pa))
rownames(taxa_pa)  <- taxa_pa[,1]
taxa_pa            <- taxa_pa[,-1]


Spec_pref  <- read.table(paste0(dir.data,file.preferences),header=TRUE,
                          sep="\t", stringsAsFactors=FALSE)
Spec_pref <- Spec_pref[,-1]

taxalist_ID_connect <- read.table(paste0(dir.data,file.taxaID),header=TRUE,
                              sep="\t", stringsAsFactors=FALSE)
taxalist_ID_connect <- taxalist_ID_connect %>% mutate(ID_Art = as.character(ID_Art))

# Calculate co-occurrences

cooccurrence_count <- crossprod(as.matrix(taxa_pa[-51,-c(108:110)]))
diag(cooccurrence_count) <- NA

# Convert table to data frame
cooccurrence_df <- as.data.frame(cooccurrence_count)

# Reshape data to long format
cooccurrence_long <- cooccurrence_df %>% rownames_to_column(var = "species2") %>% 
  pivot_longer(-species2, 
               names_to= "species1", 
               values_to = "cooccurrence")

cooccurrence_long <- left_join(cooccurrence_long, taxalist_ID_connect, by=c("species2" = "ID_Art"))
cooccurrence_long <- left_join(cooccurrence_long, taxalist_ID_connect, by=c("species1" = "ID_Art"))


# calculate Gower index for all species

Spec_pref_gow <- as.data.frame(Spec_pref)
rownames(Spec_pref_gow) <- Spec_pref_gow[,3]

Spec_pref_gow <- Spec_pref_gow[,-c(1,2)]

Spec_pref_gow_sub <- Spec_pref[Spec_pref_gow$Taxonname %in% unique(cooccurrence_long$Taxonname.x),]

gow_all <- gawdis(Spec_pref_gow[,-c(1)], w.type="equal", 
                  groups =c(rep(1,10), rep(2,8)), fuzzy= c(1,2))

attr(gow_all,"correls")

gow_all_mat <- as.matrix(gow_all)
gow_all_mat_sim <- 1-gow_all_mat

gow_all_long <- reshape2::melt(gow_all_mat_sim)
gow_all_long <- gow_all_long %>%  subset(Var1!= Var2)

gow_coocurr <- merge(gow_all_long,cooccurrence_long, by.x = c("Var1", "Var2"), by.y= c("Taxonname.x", "Taxonname.y"))
gow_coocurr <- na.omit(gow_coocurr)


# dataframe with speciesname, site and occurrence

taxa_occ_site <- gather(taxa_pa, key = "sp", value = "occ", -ID_Y, -ID, -Year)


# Filter rows where occurrence is 0 (absent)
absent_df <- subset(taxa_occ_site, occ==0)

# Filter rows where occurrence is 1 (present)
present_df <- subset(taxa_occ_site, occ==1)

# Create all possible combinations of absent species with present species for each site
site_pairs <- merge(absent_df, present_df, by = "ID")

# Select columns for the final table
final_table <- site_pairs[, c("sp.x", "sp.y", "ID")]

# Rename columns
colnames(final_table) <- c("sp_abs", "sp_pres", "ID")

# Print the final table
print(final_table)


# add gower similarity values

final_table_wgower <- merge(final_table,gow_coocurr, by.x = c("sp_abs", "sp_pres"), by.y= c("species2", "species1"))

final_table_wgower_max <- final_table_wgower %>%
  group_by(Var1, ID) %>%
  summarize(max_value = max(value))

#select main sites
main_sites <- c("BOYkl", "BRAohBo", "BRAob", "QUAohBo", "SCHohVo", 
                  "LIEohBo", "BOYuhHa", "NATohBo", "BOYohB224", "BOYohKi",
                  "BOYohSp", "BOYuhSp", "KIRun", "KIRob", "BOYohBr",
                  "HAAun", "HAAob", "WITob", "VORuhSc", "VORohBo")

# max similarity between present and absent taxa per site (for main sites)

final_table_wgower_max_main <- final_table_wgower_max %>% subset(ID %in% main_sites)


# ----------------------------------------
# same procedure for present species  ####
# ----------------------------------------

# dataframe with speciesname, site and occurrence

taxa_occ_site <- gather(taxa_pa, key = "sp", value = "occ", -ID_Y, -ID, -Year)


# Create all possible combinations of absent species with present species for each site
site_pairs_pr <- merge(present_df, present_df, by = "ID")

# Select columns for the final table
final_table_pr <- site_pairs_pr[, c("sp.x", "sp.y", "ID")]

# Rename columns
colnames(final_table_pr) <- c("sp_pres1", "sp_pres2", "ID")

final_table_pr <- final_table_pr %>% subset(sp_pres1 != sp_pres2)

# Print the final table
print(final_table_pr)

#add gower similarity values

final_table_wgower_pr <- merge(final_table_pr,gow_coocurr, by.x = c("sp_pres1", "sp_pres2"), by.y= c("species2", "species1"))

final_table_wgower_pr_max <- final_table_wgower_pr %>%
  group_by(Var1, ID) %>%
  summarize(max_value = max(value))

# max similarity between present taxa per site (for main sites)
final_table_wgower_pr_max_main <- final_table_wgower_pr_max %>% subset(ID %in% RESIST_sites)

# compare present with absent species
gower_pres_abs_compare <- rbind(final_table_wgower_pr_max_main, final_table_wgower_max_main)

# add habitat suitability and distance to source
# load table that contains results of habitat suitability and source populations

habsuit_dist    <- read.table(paste0(dir.data, file.habitat_dist),header=TRUE,
                         sep="\t", stringsAsFactors=FALSE)


gower_pres_abs_compare <- merge(gower_pres_abs_compare, 
                                 habsuit_dist, 
                                by.x = c("Var1", "ID"), by.y= c("species", "ID"))

# use dataframe gower_pres_abs_compare in next script "2_Fig4_6_8_barplot_linear_regression_pipeline" fo the
# logistic regression analysis and barplots
