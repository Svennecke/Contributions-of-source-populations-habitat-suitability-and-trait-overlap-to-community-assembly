# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# > Combine habitat suitability tables ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#
# Combine Habitat suitabilities
#
# Authors: Svenja Gillmann
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=

setwd() # set working directory to source file

# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Packages and functions ####
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=

if ( !require("dplyr") ) { install.packages("dplyr"); library("dplyr") }
if ( !require("tidyr") ) { install.packages("tidyr"); library("tidyr") }  
if ( !require("lubridate") ) { install.packages("lubridate"); library("lubridate") }


#load output from Traitscore Script

habsuit_saprobity <- read.table(paste0(dir.input,"Habitat_suitability/habsuit_saprobity_2022.dat"),header=TRUE,
                                sep="\t", stringsAsFactors=FALSE)
habsuit_sub <- read.table(paste0(dir.input,"Habitat_suitability/habsuit_substrate_2022.dat"),header=TRUE,
                          sep="\t", stringsAsFactors=FALSE)
habsuit_temp <- read.table(paste0(dir.input,"Habitat_suitability/habsuit_temp_2022.dat"),header=TRUE,
                           sep="\t", stringsAsFactors=FALSE)
habsuit_velocity <- read.table(paste0(dir.input,"Habitat_suitability/habsuit_velocity_2022.dat"),header=TRUE,
                               sep="\t", stringsAsFactors=FALSE)

# create dataframe that only contains all habitat suitabilities
habsuit_velocity <- habsuit_velocity %>% arrange(ID_Year)
habsuit_saprobity <- habsuit_saprobity %>% arrange(ID_Year)

habsuit_bind_all <- left_join(cbind(habsuit_velocity, habsuit_saprobity[,-1]), habsuit_sub)
habsuit_bind_all <- left_join(habsuit_bind_all, habsuit_temp)
rownames(habsuit_bind_all) <- habsuit_bind_all$ID_Year

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# > aggregate habitat suitabilities per species ####
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#aggregate habitat suitabilities 

habsuit_bind_all_t <- gather(data = habsuit_bind_all, 
                             key = Taxon, value = suitability,
                             -ID_Year)
habsuit_bind_all_t$taxon  <-  gsub(".*\\.", "", habsuit_bind_all_t$Taxon)

habsuit_bind_all_t_mean    <-  aggregate(habsuit_bind_all_t$suitability,by= list(
  taxon = habsuit_bind_all_t$taxon, 
  site= habsuit_bind_all_t$ID_Year), 
  FUN=mean, na.rm=T)

# add info for present/absent to table
# load community data

comm_dat_t_short_table <- read.table(paste0(dir.input,"Habitat_suitability/comm_data_2022.dat"),header=T,sep="\t",
                                     stringsAsFactors=T)
comm_dat_t_short_table <- comm_dat_t_short_table[,-1]

habsuit_bind_all_t_mean <- merge(habsuit_bind_all_t_mean, comm_dat_t_short_table, by.x = c("taxon", "site"), 
                                 by.y = c("Taxon", "site"))

##### All habitat suitabilities in long format ####

habsuit_long <- habsuit_bind_all_t_mean %>% rename("mean_habsuit"= "x")
habsuit_long$year <- gsub(".*_", "", habsuit_long$site)
habsuit_long$ID   <- gsub("\\_.*", "", habsuit_long$site)

# use final table in next R-script "2_Fig4_6_8_barplot_linear_regression_pipeline.R"
# for the linear regression analysis and to create barplots 